const btn = document.createElement("button");
btn.innerHTML = "Génères moi le tableau";
btn.style = "width: 200px; height:50px;";
document.getElementById("resultat").appendChild(btn);

btn.addEventListener("click", generation);

function generation() {
  let names = [
    "Perceval",
    "Karadoc",
    "Arthur",
    "Guenièvre",
    "Ivain",
    "Gauvain",
    "Léodagan",
    "Lancelot",
    "Bohort",
    "Merlin",
  ];
  // Génère la div card
  const divCard = document.createElement("div");
  divCard.classList.add("card");
  divCard.style = "width: 18rem;";
  document.getElementById("resultat").appendChild(divCard);

  // Génère image
  let randomNum = Math.floor(Math.random() * 99); //Génère un chiffre aléatoire
  const imageTop = document.createElement("img");
  imageTop.classList.add("card-img-top");
  imageTop.alt = "image aléatoire";
  imageTop.src = "https://picsum.photos/200/300?random=" + randomNum; //URL + le chiffre aléatoire
  divCard.appendChild(imageTop);

  // Génère div Card Body
  const divCardBody = document.createElement("div");
  divCardBody.classList.add("card-body");
  divCard.appendChild(divCardBody);

  // Génère h5
  let nomAp = names[Math.floor(Math.random() * names.length)]; //Prends un nom aléatoire dans le tableau names et le met dans la variable nomAp
  const divCardTitle = document.createElement("h5");
  divCardTitle.innerHTML = nomAp;
  divCardTitle.classList.add("card-title");
  divCardBody.appendChild(divCardTitle);
}
